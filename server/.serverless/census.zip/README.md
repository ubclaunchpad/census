# census

Serverless deployment steps:
<ul>  

<li>Adjust implementation logic in handler.js
<li>Adjust serverless.yml accordingly with function name

</ul>
Type the following into the command line:
<ol>
<li>serverless config credentials --provider aws --key *YOUR KEY* --secret *YOUR SECRET KEY* --overwrite</bold>
<li>serverless deploy

</ol>






